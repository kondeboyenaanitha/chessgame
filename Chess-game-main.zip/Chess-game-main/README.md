# Chess-game
## Chess game with java swing
# Update
* checkmate works
* stalemate works
* castling the king  works 
* capture pieces works
* promote pawn to knight/bishop/queen/rook works
* enpassant rule works

# TODO
* impement ai to play the game
* refactoring because the code is a mess
